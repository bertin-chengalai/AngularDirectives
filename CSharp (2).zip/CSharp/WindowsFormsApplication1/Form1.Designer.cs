﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ClearDatabase = new System.Windows.Forms.Button();
            this.testBuy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ClearDatabase
            // 
            this.ClearDatabase.Location = new System.Drawing.Point(123, 160);
            this.ClearDatabase.Name = "ClearDatabase";
            this.ClearDatabase.Size = new System.Drawing.Size(170, 23);
            this.ClearDatabase.TabIndex = 0;
            this.ClearDatabase.Text = "Clear Database";
            this.ClearDatabase.UseVisualStyleBackColor = true;
            this.ClearDatabase.Click += new System.EventHandler(this.ClearDatabase_Click);
            // 
            // testBuy
            // 
            this.testBuy.Location = new System.Drawing.Point(401, 160);
            this.testBuy.Name = "testBuy";
            this.testBuy.Size = new System.Drawing.Size(75, 23);
            this.testBuy.TabIndex = 1;
            this.testBuy.Text = "TestBuy";
            this.testBuy.UseVisualStyleBackColor = true;
            this.testBuy.Click += new System.EventHandler(this.testBuy_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 261);
            this.Controls.Add(this.testBuy);
            this.Controls.Add(this.ClearDatabase);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ClearDatabase;
        private System.Windows.Forms.Button testBuy;
    }
}


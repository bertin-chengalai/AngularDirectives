﻿using IBApi;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Threading;
using System.Collections.ObjectModel;
using System.Diagnostics;
using ClassLibrary;
using System.Threading;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private readonly DispatcherTimer timer = new DispatcherTimer(DispatcherPriority.Background);
        private readonly DispatcherTimer timerfetch = new DispatcherTimer(DispatcherPriority.Background);
        EReaderMonitorSignal signal = new EReaderMonitorSignal();
        IBClient ibClient;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timerfetch.Interval = new TimeSpan(0, 0, 10);
            timerfetch.Tick += (o, u) =>
            {
                StockEngine.FetchBuyOrSell();
            };
            timerfetch.Start();
            ConnectClient();
        } 

      private void ClearDatabase_Click(object sender, EventArgs e)
        {
            SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");
            SqlCommand testCMD = new SqlCommand("CleanDB", PubsConn);
            testCMD.CommandType = CommandType.StoredProcedure;
            PubsConn.Open();
            SqlDataReader reader = testCMD.ExecuteReader();
            var dataTable = new DataTable();
            dataTable.Load(reader);
            PubsConn.Close();
        }

        private void testBuy_Click(object sender, EventArgs e)
        {
            
            BuySell bs = new BuySell();
            bs.Buy("NVDA", 1, Convert.ToDecimal( 10.23), "", "");

        }

        private void ConnectClient()
        {
            int port;
            string host = "";
            ibClient = new IBClient(signal);

            if (host == null || host.Equals(""))
                host = "127.0.0.1";
            try
            {
                port = Int32.Parse("7946");
                ibClient.ClientId = Int32.Parse("1");
                ibClient.ClientSocket.eConnect(host, port, ibClient.ClientId);

                var reader = new EReader(ibClient.ClientSocket, signal);

                reader.Start();

                new Thread(() => { while (ibClient.ClientSocket.IsConnected()) { signal.waitForSignal(); reader.processMsgs(); } }) { IsBackground = true }.Start();
            }
            catch (Exception)
            {
                //HandleMessage(new ErrorMessage(-1, -1, "Please check your connection attributes."));
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace WindowsFormsApplication1
{
   public static class StockEngine
    {
        public static void FetchBuyOrSell()
        {
            string identifier;
            string indicator;
            int qty;
            decimal lastPrice;


            try
            {
                BuySell bs = new BuySell();
                SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");
                SqlConnection PubsConn1 = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");
                SqlCommand testCMD = new SqlCommand("ReadDecisionTableTop3", PubsConn);
                testCMD.CommandType = CommandType.StoredProcedure;
                PubsConn.Open();
                SqlDataReader reader = testCMD.ExecuteReader();

                var dataTable = new DataTable();
                dataTable.Load(reader);

                PubsConn.Close();
                if (dataTable.Rows.Count > 0)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        identifier = dataTable.Rows[i]["identifier"].ToString();
                        indicator = dataTable.Rows[i]["indicator"].ToString();
                        lastPrice = (decimal)dataTable.Rows[i]["lastprice"];
                        qty = (int)(100000 / lastPrice);
                        qty = qty - 1;
                        if (indicator == "buy")
                        {
                            bs.Buy(identifier, qty, lastPrice, "097471383", "Windows8");
                        }
                        if (indicator == "sell")
                        {
                            bs.Sell(identifier, qty, lastPrice, "097471383", "Windows8");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("No rows found.");
                }
                reader.Close();
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}

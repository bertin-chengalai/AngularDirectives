﻿using System;
using IBApi;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class BuySell
    {
        private int orderId;
        private IBClient ibClient;

        public BuySell()
        {

        }

        public void Buy(string stock, long qty, decimal lastPrice, string userName, string password)
        {

            try
            {
                Contract contract = GetOrderContract(stock, "STK", "USD", "SMART");
                Order order = MarketOrder("BUY",1);
                PlaceOrder(contract, order);               

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {

            }
        }

        public void PlaceOrder(Contract contract, Order order)
        {
               EReaderMonitorSignal signal = new EReaderMonitorSignal();
              ibClient = new IBClient(signal);
            if (order.OrderId != 0)
            {
                ibClient.ClientSocket.placeOrder(order.OrderId, contract, order);
            }
            else
            {
                ibClient.ClientSocket.placeOrder(ibClient.NextOrderId, contract, order);
                ibClient.NextOrderId++;
            }
        }

      
        private Contract GetOrderContract(string contractSymbol, string contractSecType, string contractCurrency, string contractExchange)
        {
            Contract contract = new Contract();
            contract.Symbol = contractSymbol;
            contract.SecType = contractSecType;
            contract.Currency = contractCurrency;
            contract.Exchange = contractExchange;
            return contract;
        }

        public Order MarketOrder(string action, double quantity)
        {
            //! [market]
            Order order = new Order();
            order.Action = action;
            order.OrderType = "MKT";
            order.TotalQuantity = quantity;
            //! [market]
            return order;
        }

        public void Sell(string stock, int qty, decimal lastPrice, string userName, string password)
        {
           
            {
                try
                {
                    try
                    {
                        Contract contract = GetOrderContract(stock, "STK", "USD", "SMART");
                        Order order = MarketOrder("BUY", 1);
                        PlaceOrder(contract, order);

                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                    finally
                    {

                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
                finally
                {
                   
                }
            }
        }
    }
}

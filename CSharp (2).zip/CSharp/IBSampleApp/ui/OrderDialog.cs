﻿/* Copyright (C) 2013 Interactive Brokers LLC. All rights reserved.  This code is subject to the terms
 * and conditions of the IB API Non-Commercial License or the IB API Commercial License, as applicable. */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IBApi;
using IBSampleApp.ui;
using IBSampleApp.messages;
using IBSampleApp.types;
using System.Windows.Threading;
using System.Threading;
using System.Data.SqlClient;

namespace IBSampleApp
{
    public partial class OrderDialog : Form
    {
        private MarginDialog marginDialog;
        private OrderManager orderManager;
        private int orderId;
        private BindingSource orderBindingSource = new BindingSource();
        #region App Area   

        public OrderDialog(OrderManager orderManager)
        {
            InitializeComponent();
            InitialiseDropDowns();
            InitializeComponentGrid();
            RefreshGridView();
            //Thread.Sleep(3000);
            //RefreshGridView();
            //Thread.Sleep(3000);
            RefreshGridViewBuySell();

            timerfetch.Interval = new TimeSpan(0, 0, 3);
            timerfetch.Tick += (o, u) =>
            {
                RefreshGridView();
            };
            timerfetch.Start();

            timerfetchBuySell.Interval = new TimeSpan(0, 0, 3);
            timerfetchBuySell.Tick += (o, u) =>
            {
                RefreshGridViewBuySell();
            };
            timerfetchBuySell.Start();

            this.orderManager = orderManager;
            marginDialog = new MarginDialog();
            contractSearchControl1.IBClient = orderManager.IBClient;
            conditionList.CellFormatting += conditionList_CellFormatting;
            conditionList.DataSource = orderBindingSource;
            conditionList.AutoGenerateColumns = false;
            conditionList.CellParsing += conditionList_CellParsing;
            orderBindingSource.DataSource = new List<OrderCondition>();
            cancelOrder.SelectedIndex = 0;

        }

        public void InitializeComponentGrid()
        {
            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            btn.HeaderText = "Buy";
            btn.Name = "Buy";
            btn.Text = "Buy";
            btn.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(btn);

            DataGridViewButtonColumn btn1 = new DataGridViewButtonColumn();
            btn1.HeaderText = "Sell";
            btn1.Name = "Sell";
            btn1.Text = "Sell";
            btn1.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(btn1);

            DataGridViewButtonColumn btn3 = new DataGridViewButtonColumn();
            btn3.HeaderText = "Buy";
            btn3.Name = "Buy";
            btn3.Text = "Buy";
            btn3.UseColumnTextForButtonValue = true;
            dataGridView2.Columns.Add(btn3);

            DataGridViewButtonColumn btn4 = new DataGridViewButtonColumn();
            btn4.HeaderText = "Sell";
            btn4.Name = "Sell";
            btn4.Text = "Sell";
            btn4.UseColumnTextForButtonValue = true;
            dataGridView2.Columns.Add(btn4);
        }

        void conditionList_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                e.ParsingApplied = false;

                return;
            }

            (orderBindingSource[e.RowIndex] as OrderCondition).IsConjunctionConnection = e.Value.ToString().Equals("and", StringComparison.InvariantCultureIgnoreCase);
        }

        void conditionList_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

        }

        public Order CurrentOrder
        {
            set { SetOrder(value); }
        }



        private void checkMarginButton_Click(object sender, EventArgs e)
        {
            Contract contract = GetOrderContract();
            Order order = GetOrder();
            order.WhatIf = true;
            orderManager.PlaceOrder(contract, order);
        }

        public void HandleIncomingMessage(IBMessage message)
        {
            ProcessMessage(message);
        }

        private void ProcessMessage(IBMessage message)
        {
            switch (message.Type)
            {
                case MessageType.OpenOrder:
                    HandleOpenOrder((OpenOrderMessage)message);
                    break;
                case MessageType.SoftDollarTiers:
                    HandleSoftDollarTiers((SoftDollarTiersMessage)message);
                    break;
            }
        }

        private void HandleSoftDollarTiers(SoftDollarTiersMessage softDollarTiersMessage)
        {
            softDollarTier.Items.AddRange(softDollarTiersMessage.Tiers);
        }

        private void HandleOpenOrder(OpenOrderMessage openOrderMessage)
        {
            if (openOrderMessage.Order.WhatIf)
                this.marginDialog.UpdateMarginInformation(openOrderMessage.OrderState);
        }

        private void closeOrderDialogButton_Click(object sender, EventArgs e)
        {
            if (orderId != 0)
                orderId = 0;
            this.Visible = false;
        }

        private void AlgoStrategy_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox algoStrategyCombo = (ComboBox)sender;
            string selectedStrategy = (string)algoStrategyCombo.SelectedItem;
            DisableAlgoParams();
            switch (selectedStrategy)
            {
                case "Vwap":
                    EnableVWap();
                    break;
                case "Twap":
                    EnableTWap();
                    break;
                case "ArrivalPx":
                    EnableArrivalPx();
                    break;
                case "DarkIce":
                    EnableDarkIce();
                    break;
                case "PctVol":
                    EnablePctVol();
                    break;
            }
        }

        private void DisableAlgoParams()
        {
            startTime.Enabled = false;
            endTime.Enabled = false;
            allowPastEndTime.Enabled = false;
            maxPctVol.Enabled = false;
            pctVol.Enabled = false;
            strategyType.Enabled = false;
            noTakeLiq.Enabled = false;
            riskAversion.Enabled = false;
            forceCompletion.Enabled = false;
            displaySizeAlgo.Enabled = false;
            getDone.Enabled = false;
            noTradeAhead.Enabled = false;
            useOddLots.Enabled = false;
        }

        public void SetManagedAccounts(List<string> managedAccounts)
        {
            account.Items.AddRange(managedAccounts.ToArray());
            account.SelectedIndex = 0;
        }

        private Contract GetOrderContract()
        {
            Contract contract = new Contract();
            contract.Symbol = contractSymbol.Text;
            contract.SecType = contractSecType.Text;
            contract.Currency = contractCurrency.Text;
            contract.Exchange = contractExchange.Text;
            contract.LastTradeDateOrContractMonth = contractLastTradeDateOrContractMonth.Text;
            if (!contractStrike.Text.Equals(""))
                contract.Strike = Double.Parse(contractStrike.Text);
            if (!contractRight.Text.Equals("") || !contractRight.Text.Equals("None"))
                contract.Right = (string)((IBType)contractRight.SelectedItem).Value;
            contract.LocalSymbol = contractLocalSymbol.Text;
            contract.PrimaryExch = contractPrimaryExch.Text;
            return contract;
        }
        private Contract GetOrderContract_mine(string symbol)
        {
            Contract contract = new Contract();
            contract.Symbol = symbol;
            contract.SecType = "STK";
            contract.Currency = "USD";
            contract.Exchange = "SMART";
            contract.LastTradeDateOrContractMonth = contractLastTradeDateOrContractMonth.Text;
            if (!contractStrike.Text.Equals(""))
                contract.Strike = Double.Parse(contractStrike.Text);
            if (!contractRight.Text.Equals("") || !contractRight.Text.Equals("None"))
                contract.Right = (string)((IBType)contractRight.SelectedItem).Value;
            contract.LocalSymbol = contractLocalSymbol.Text;
            contract.PrimaryExch = contractPrimaryExch.Text;
            return contract;
        }

        public void SetOrderContract(Contract contract)
        {
            contractSymbol.Text = contract.Symbol;
            contractSecType.Text = contract.SecType;
            contractCurrency.Text = contract.Currency;
            contractExchange.Text = contract.Exchange;
            contractLastTradeDateOrContractMonth.Text = contract.LastTradeDateOrContractMonth;
            contractStrike.Text = contract.Strike.ToString();
            contractRight.Text = contract.Right;
            contractLocalSymbol.Text = contract.LocalSymbol;
        }

        private Order GetOrder()
        {
            Order order = new Order();
            if (orderId != 0)
                order.OrderId = orderId;
            order.Action = action.Text;
            order.OrderType = orderType.Text;
            if (!lmtPrice.Text.Equals(""))
                order.LmtPrice = Double.Parse(lmtPrice.Text);
            if (!quantity.Text.Equals(""))
                order.TotalQuantity = Double.Parse(quantity.Text);
            order.Account = account.Text;
            order.ModelCode = modelCode.Text;
            order.Tif = timeInForce.Text;
            if (!auxPrice.Text.Equals(""))
                order.AuxPrice = Double.Parse(auxPrice.Text);
            if (!displaySize.Text.Equals(""))
                order.DisplaySize = Int32.Parse(displaySize.Text);

            FillExtendedOrderAttributes(order);
            FillAdvisorAttributes(order);
            FillVolatilityAttributes(order);
            FillScaleAttributes(order);
            FillAlgoAttributes(order);
            FillPegToBench(order);
            FillAdjustedStops(order);
            FillConditions(order);

            return order;
        }

        private Order GetOrder_mine(Double qty)
        {
            Order order = new Order();
            if (orderId != 0)
                order.OrderId = orderId;
            order.Action = "BUY";
            order.OrderType = "MKT";
            order.TotalQuantity = qty;
            if (!lmtPrice.Text.Equals(""))
                order.LmtPrice = Double.Parse(lmtPrice.Text);
            if (!quantity.Text.Equals(""))
               
            order.Account = account.Text;
            order.ModelCode = modelCode.Text;
            order.Tif = timeInForce.Text;
            if (!auxPrice.Text.Equals(""))
                order.AuxPrice = Double.Parse(auxPrice.Text);
            if (!displaySize.Text.Equals(""))
                order.DisplaySize = Int32.Parse(displaySize.Text);

            FillExtendedOrderAttributes(order);
            FillAdvisorAttributes(order);
            FillVolatilityAttributes(order);
            FillScaleAttributes(order);
            FillAlgoAttributes(order);
            FillPegToBench(order);
            FillAdjustedStops(order);
            FillConditions(order);

            return order;
        }

        private Order SellOrder_mine(Double qty)
        {
            Order order = new Order();
            if (orderId != 0)
                order.OrderId = orderId;
            order.Action = "SELL";
            order.OrderType = "MKT";
            if (!lmtPrice.Text.Equals(""))
                order.LmtPrice = Double.Parse(lmtPrice.Text);
            if (!quantity.Text.Equals(""))
                order.TotalQuantity = qty;
            order.Account = account.Text;
            order.ModelCode = modelCode.Text;
            order.Tif = timeInForce.Text;
            if (!auxPrice.Text.Equals(""))
                order.AuxPrice = Double.Parse(auxPrice.Text);
            if (!displaySize.Text.Equals(""))
                order.DisplaySize = Int32.Parse(displaySize.Text);

            FillExtendedOrderAttributes(order);
            FillAdvisorAttributes(order);
            FillVolatilityAttributes(order);
            FillScaleAttributes(order);
            FillAlgoAttributes(order);
            FillPegToBench(order);
            FillAdjustedStops(order);
            FillConditions(order);

            return order;
        }

        private void FillConditions(Order order)
        {
            order.Conditions = orderBindingSource.DataSource as List<OrderCondition>;
            order.ConditionsIgnoreRth = ignoreRth.Checked;
            order.ConditionsCancelOrder = cancelOrder.SelectedIndex == 1;
        }

        private void FillAdjustedStops(Order order)
        {
            if (cbAdjustedOrderType.SelectedIndex > 0)
                order.AdjustedOrderType = cbAdjustedOrderType.Text;

            if (!string.IsNullOrWhiteSpace(tbTriggerPrice.Text))
                order.TriggerPrice = double.Parse(tbTriggerPrice.Text);

            if (!string.IsNullOrWhiteSpace(tbAdjustedStopPrice.Text))
                order.AdjustedStopPrice = double.Parse(tbAdjustedStopPrice.Text);

            if (!string.IsNullOrWhiteSpace(tbAdjustedStopLimitPrice.Text))
                order.AdjustedStopLimitPrice = double.Parse(tbAdjustedStopLimitPrice.Text);

            if (!string.IsNullOrWhiteSpace(tbAdjustedTrailingAmnt.Text))
                order.AdjustedTrailingAmount = double.Parse(tbAdjustedTrailingAmnt.Text);

            order.AdjustableTrailingUnit = (cbAdjustedTrailingAmntUnit.SelectedItem as TrailingAmountUnit).Val;
            order.LmtPriceOffset = order.LmtPrice - order.AuxPrice;
        }

        private void FillPegToBench(Order order)
        {
            if (!string.IsNullOrWhiteSpace(tbStartingPrice.Text))
                order.StartingPrice = double.Parse(tbStartingPrice.Text);

            if (!string.IsNullOrWhiteSpace(tbStartingReferencePrice.Text))
                order.StockRefPrice = double.Parse(tbStartingReferencePrice.Text);

            if (!string.IsNullOrWhiteSpace(tbPeggedChangeAmount.Text))
                order.PeggedChangeAmount = double.Parse(tbPeggedChangeAmount.Text);

            if (!string.IsNullOrWhiteSpace(tbReferenceChangeAmount.Text))
                order.ReferenceChangeAmount = double.Parse(tbReferenceChangeAmount.Text);

            if (!string.IsNullOrWhiteSpace(pgdStockRangeLower.Text))
                order.StockRangeLower = double.Parse(pgdStockRangeLower.Text);

            if (!string.IsNullOrWhiteSpace(pgdStockRangeUpper.Text))
                order.StockRangeUpper = double.Parse(pgdStockRangeUpper.Text);

            order.IsPeggedChangeAmountDecrease = cbPeggedChangeType.SelectedIndex == 1;

            if (contractSearchControl1.Contract != null)
            {
                order.ReferenceContractId = contractSearchControl1.Contract.ConId;
                order.ReferenceExchange = contractSearchControl1.Contract.Exchange;
            }
        }

        private void FillExtendedOrderAttributes(Order order)
        {
            order.OrderRef = orderReference.Text;
            if (!minQty.Text.Equals(""))
                order.MinQty = Int32.Parse(minQty.Text);
            order.GoodAfterTime = goodAfter.Text;
            order.GoodTillDate = goodUntil.Text;
            order.Rule80A = (string)((IBType)rule80A.SelectedItem).Value;
            order.TriggerMethod = (int)((IBType)triggerMethod.SelectedItem).Value;

            if (!percentOffset.Text.Equals(""))
                order.PercentOffset = Double.Parse(percentOffset.Text);
            if (!trailStopPrice.Text.Equals(""))
                order.TrailStopPrice = Double.Parse(trailStopPrice.Text);
            if (!trailingPercent.Text.Equals(""))
                order.TrailingPercent = Double.Parse(trailingPercent.Text);
            if (!discretionaryAmount.Text.Equals(""))
                order.DiscretionaryAmt = Int32.Parse(discretionaryAmount.Text);
            if (!nbboPriceCap.Text.Equals(""))
                order.NbboPriceCap = Double.Parse(nbboPriceCap.Text);

            order.OcaGroup = ocaGroup.Text;
            order.OcaType = (int)((IBType)ocaType.SelectedItem).Value;
            order.HedgeType = (string)((IBType)hedgeType.SelectedItem).Value;
            order.HedgeParam = hedgeParam.Text;

            order.NotHeld = notHeld.Checked;
            order.BlockOrder = block.Checked;
            order.SweepToFill = sweepToFill.Checked;
            order.Hidden = hidden.Checked;
            order.OutsideRth = outsideRTH.Checked;
            order.AllOrNone = allOrNone.Checked;
            order.OverridePercentageConstraints = overrideConstraints.Checked;
            order.ETradeOnly = eTrade.Checked;
            order.FirmQuoteOnly = firmQuote.Checked;
            order.OptOutSmartRouting = optOutSmart.Checked;
            order.Transmit = transmit.Checked;
            order.Tier = softDollarTier.SelectedItem as SoftDollarTier ?? new SoftDollarTier("", "", "");
        }

        private void FillVolatilityAttributes(Order order)
        {
            if (!volatility.Text.Equals(""))
                order.Volatility = Double.Parse(volatility.Text);
            order.VolatilityType = (int)((IBType)volatilityType.SelectedItem).Value;
            if (continuousUpdate.Checked)
                order.ContinuousUpdate = 1;
            else
                order.ContinuousUpdate = 0;
            order.ReferencePriceType = (int)((IBType)optionReferencePrice.SelectedItem).Value;

            if (!deltaNeutralOrderType.Text.Equals("None"))
                order.DeltaNeutralOrderType = deltaNeutralOrderType.Text;

            if (!deltaNeutralAuxPrice.Text.Equals(""))
                order.DeltaNeutralAuxPrice = Double.Parse(deltaNeutralAuxPrice.Text);
            if (!deltaNeutralConId.Text.Equals(""))
                order.DeltaNeutralConId = Int32.Parse(deltaNeutralConId.Text);
            if (!stockRangeLower.Text.Equals(""))
                order.StockRangeLower = Double.Parse(stockRangeLower.Text);
            if (!stockRangeUpper.Text.Equals(""))
                order.StockRangeUpper = Double.Parse(stockRangeUpper.Text);
        }

        private void FillAdvisorAttributes(Order order)
        {
            order.FaGroup = faGroup.Text;
            order.FaPercentage = faPercentage.Text;
            order.FaMethod = (string)((IBType)faMethod.SelectedItem).Value;
            order.FaProfile = faProfile.Text;
        }

        private void FillScaleAttributes(Order order)
        {
            if (!initialLevelSize.Text.Equals(""))
                order.ScaleInitLevelSize = Int32.Parse(initialLevelSize.Text);
            if (!subsequentLevelSize.Text.Equals(""))
                order.ScaleSubsLevelSize = Int32.Parse(subsequentLevelSize.Text);
            if (!priceIncrement.Text.Equals(""))
                order.ScalePriceIncrement = Double.Parse(priceIncrement.Text);
            if (!priceAdjustValue.Text.Equals(""))
                order.ScalePriceAdjustValue = Double.Parse(priceAdjustValue.Text);
            if (!priceAdjustInterval.Text.Equals(""))
                order.ScalePriceAdjustInterval = Int32.Parse(priceAdjustInterval.Text);
            if (!profitOffset.Text.Equals(""))
                order.ScaleProfitOffset = Double.Parse(profitOffset.Text);
            if (!initialPosition.Text.Equals(""))
                order.ScaleInitPosition = Int32.Parse(initialPosition.Text);
            if (!initialFillQuantity.Text.Equals(""))
                order.ScaleInitFillQty = Int32.Parse(initialFillQuantity.Text);

            order.ScaleAutoReset = autoReset.Checked;
            order.ScaleRandomPercent = randomiseSize.Checked;
        }

        private void FillAlgoAttributes(Order order)
        {
            if (algoStrategy.Text.Equals("") || algoStrategy.Text.Equals("None"))
                return;
            List<TagValue> algoParams = new List<TagValue>();
            algoParams.Add(new TagValue("startTime", startTime.Text));
            algoParams.Add(new TagValue("endTime", endTime.Text));

            order.AlgoStrategy = algoStrategy.Text;

            /*Vwap Twap ArrivalPx DarkIce PctVol*/
            if (order.AlgoStrategy.Equals("VWap"))
            {
                algoParams.Add(new TagValue("maxPctVol", maxPctVol.Text));
                algoParams.Add(new TagValue("noTakeLiq", noTakeLiq.Text));
                algoParams.Add(new TagValue("getDone", getDone.Text));
                algoParams.Add(new TagValue("noTradeAhead", noTradeAhead.Text));
                algoParams.Add(new TagValue("useOddLots", useOddLots.Text));
                algoParams.Add(new TagValue("allowPastEndTime", allowPastEndTime.Text));
            }

            if (order.AlgoStrategy.Equals("Twap"))
            {
                algoParams.Add(new TagValue("strategyType", strategyType.Text));
                algoParams.Add(new TagValue("allowPastEndTime", allowPastEndTime.Text));
            }

            if (order.AlgoStrategy.Equals("ArrivalPx"))
            {
                algoParams.Add(new TagValue("allowPastEndTime", allowPastEndTime.Text));
                algoParams.Add(new TagValue("maxPctVol", maxPctVol.Text));
                algoParams.Add(new TagValue("riskAversion", riskAversion.Text));
                algoParams.Add(new TagValue("forceCompletion", forceCompletion.Text));
            }

            if (order.AlgoStrategy.Equals("DarkIce"))
            {
                algoParams.Add(new TagValue("allowPastEndTime", allowPastEndTime.Text));
                algoParams.Add(new TagValue("displaySize", displaySizeAlgo.Text));
            }

            if (order.AlgoStrategy.Equals("PctVol"))
            {
                algoParams.Add(new TagValue("pctVol", pctVol.Text));
                algoParams.Add(new TagValue("noTakeLiq", noTakeLiq.Text));
            }
            order.AlgoParams = algoParams;
        }

        public async void SetOrder(Order order)
        {
            orderId = order.OrderId;
            action.Text = order.Action;
            orderType.Text = order.OrderType;
            lmtPrice.Text = doubleToStr(order.LmtPrice);
            quantity.Text = doubleToStr(order.TotalQuantity);
            account.Text = order.Account;
            modelCode.Text = order.ModelCode;
            timeInForce.Text = order.Tif;
            auxPrice.Text = doubleToStr(order.AuxPrice);
            displaySize.Text = order.DisplaySize.ToString();

            //order = GetExtendedOrderAttributes(order);
            //order = GetAdvisorAttributes(order);
            //order = GetVolatilityAttributes(order);
            //order = GetScaleAttributes(order);
            //order = GetAlgoAttributes(order);

            var c = await orderManager.IBClient.ResolveContractAsync(order.ReferenceContractId, order.ReferenceExchange);

            contractSearchControl1.Contract = c;

            if (order.OrderType == "PEG BENCH")
            {
                tbStartingPrice.Text = doubleToStr(order.StartingPrice);
                tbStartingReferencePrice.Text = doubleToStr(order.StockRefPrice);
                tbPeggedChangeAmount.Text = doubleToStr(order.PeggedChangeAmount);
                cbPeggedChangeType.SelectedIndex = order.IsPeggedChangeAmountDecrease ? 1 : 0;
                tbReferenceChangeAmount.Text = doubleToStr(order.ReferenceChangeAmount);
                pgdStockRangeUpper.Text = doubleToStr(order.StockRangeUpper);
                pgdStockRangeLower.Text = doubleToStr(order.StockRangeLower);
            }

            cbAdjustedOrderType.Text = order.AdjustedOrderType;
            tbTriggerPrice.Text = doubleToStr(order.TriggerPrice);
            tbAdjustedStopPrice.Text = doubleToStr(order.AdjustedStopPrice);
            tbAdjustedStopLimitPrice.Text = doubleToStr(order.AdjustedStopLimitPrice);
            tbAdjustedTrailingAmnt.Text = doubleToStr(order.AdjustedTrailingAmount);
            cbAdjustedTrailingAmntUnit.SelectedItem = (TrailingAmountUnit)order.AdjustableTrailingUnit;
            orderBindingSource.DataSource = order.Conditions;
            ignoreRth.Checked = order.ConditionsIgnoreRth;
            cancelOrder.SelectedIndex = order.ConditionsCancelOrder ? 1 : 0;
        }

        string doubleToStr(double val)
        {
            return val != double.MaxValue ? val.ToString() : "";
        }

        private void EnableVWap()
        {
            startTime.Enabled = true;
            endTime.Enabled = true;
            maxPctVol.Enabled = true;
            noTakeLiq.Enabled = true;
            getDone.Enabled = true;
            noTradeAhead.Enabled = true;
            useOddLots.Enabled = true;
        }

        private void EnableTWap()
        {
            startTime.Enabled = true;
            endTime.Enabled = true;
            allowPastEndTime.Enabled = true;
            strategyType.Enabled = true;
        }

        private void EnableArrivalPx()
        {
            startTime.Enabled = true;
            endTime.Enabled = true;
            allowPastEndTime.Enabled = true;
            maxPctVol.Enabled = true;
            riskAversion.Enabled = true;
            forceCompletion.Enabled = true;
        }

        private void EnableDarkIce()
        {
            startTime.Enabled = true;
            endTime.Enabled = true;
            allowPastEndTime.Enabled = true;
            displaySizeAlgo.Enabled = true;
        }

        private void EnablePctVol()
        {
            startTime.Enabled = true;
            endTime.Enabled = true;
            pctVol.Enabled = true;
            noTakeLiq.Enabled = true;
        }

        private void InitialiseDropDowns()
        {
            rule80A.Items.AddRange(Rule80A.GetAll());
            rule80A.SelectedIndex = 0;

            triggerMethod.Items.AddRange(IBSampleApp.types.TriggerMethod.GetAll());
            triggerMethod.SelectedIndex = 0;

            faMethod.Items.AddRange(FaMethod.GetAll());
            faMethod.SelectedIndex = 0;

            ocaType.Items.AddRange(OCAType.GetAll());
            ocaType.SelectedIndex = 0;

            hedgeType.Items.AddRange(HedgeType.GetAll());
            hedgeType.SelectedIndex = 0;

            optionReferencePrice.Items.AddRange(ReferencePriceType.GetAll());
            optionReferencePrice.SelectedIndex = 0;

            volatilityType.Items.AddRange(VolatilityType.GetAll());
            volatilityType.SelectedIndex = 0;

            contractRight.Items.AddRange(ContractRight.GetAll());
            contractRight.SelectedIndex = 0;

            cbPeggedChangeType.SelectedIndex = 0;
            cbAdjustedOrderType.SelectedIndex = 0;
            cbAdjustedTrailingAmntUnit.Items[0] = TrailingAmountUnit.amnt;
            cbAdjustedTrailingAmntUnit.Items[1] = TrailingAmountUnit.percent;
            cbAdjustedTrailingAmntUnit.SelectedIndex = 0;
        }

        int reqId = 0;

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);

            if (orderManager != null && orderManager.IBClient != null && orderManager.IBClient.ClientSocket != null && orderManager.IBClient.ClientSocket.IsConnected())
                orderManager.IBClient.ClientSocket.reqSoftDollarTiers(reqId++);
        }

        class TrailingAmountUnit
        {
            public int Val { get; private set; }
            string txt;

            public override string ToString()
            {
                return txt;
            }

            private TrailingAmountUnit(int value, string text)
            {
                Val = value;
                txt = text;
            }

            public static explicit operator TrailingAmountUnit(int val)
            {
                if (val == 0)
                    return amnt;

                if (val == 100)
                    return percent;

                return null;
            }

            public static TrailingAmountUnit amnt = new TrailingAmountUnit(0, "amount"), percent = new TrailingAmountUnit(100, "%");
        }

        private void lbAddCondition_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var dlg = new ConditionDialog(null, orderManager.IBClient);

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                orderBindingSource.Add(dlg.Condition);
            }
        }

        private OrderCondition selectedCondition
        {
            get
            {
                if (conditionList.SelectedCells.Count == 0 || conditionList.SelectedCells[0].RowIndex == -1)
                    return null;

                return orderBindingSource[conditionList.SelectedCells[0].RowIndex] as OrderCondition;
            }

            set
            {
                if (conditionList.SelectedCells.Count > 0 && conditionList.SelectedCells[0].RowIndex != -1)
                    orderBindingSource[conditionList.SelectedCells[0].RowIndex] = value;
            }
        }

        private void lbRemoveCondition_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            orderBindingSource.Remove(selectedCondition);
        }

        private void conditionList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                var dlg = new ConditionDialog(selectedCondition, orderManager.IBClient);

                if (dlg.ShowDialog() == DialogResult.OK)
                    selectedCondition = dlg.Condition;
            }
        }


        private void sendOrderButton_Click(object sender, EventArgs e)
        {
            Contract contract = GetOrderContract();
            Order order = GetOrder();
            orderManager.PlaceOrder(contract, order);
            if (orderId != 0)
                orderId = 0;
            this.Visible = false;
        }
        #endregion
        private readonly DispatcherTimer timer = new DispatcherTimer(DispatcherPriority.Background);
        private readonly DispatcherTimer timerfetch = new DispatcherTimer(DispatcherPriority.Background);
        private readonly DispatcherTimer timerfetchBuySell = new DispatcherTimer(DispatcherPriority.Background);
        private readonly DispatcherTimer timerRefresh = new DispatcherTimer(DispatcherPriority.Background);
        private void Test_Buy_Click(object sender, EventArgs e)
        {
            //Thread.Sleep(10000);

            //RefreshBuyOrSell();
            //FetchBuyOrSell();
            //timerfetch.Interval = new TimeSpan(0, 0, 10);
            //timerfetch.Tick += (o, u) =>
            //{
            //    FetchBuyOrSell();
            //};
            //timerfetch.Start();

            //timerRefresh.Interval = new TimeSpan(0, 0, 20);
            //timerRefresh.Tick += (o, u) =>
            //{
            //    RefreshBuyOrSell();
            //};
            //timerRefresh.Start();
            try
            {
                //BuySell bs = new BuySell();
                SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");

                SqlCommand testCMD = new SqlCommand("CleanDB", PubsConn);
                testCMD.CommandType = CommandType.StoredProcedure;
                PubsConn.Open();
                int reader = testCMD.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void RefreshBuyOrSell()
        {
            try
            {
                //BuySell bs = new BuySell();
                SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");

                SqlCommand testCMD = new SqlCommand("fillTop3BuySellTables", PubsConn);
                testCMD.CommandType = CommandType.StoredProcedure;
                PubsConn.Open();
                int reader = testCMD.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public void UpdateDecisionTable(string identifier, decimal lastprice, long qty, string indicator)
        {
            try
            {
                //BuySell bs = new BuySell();
                SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");

                SqlCommand testCMD = new SqlCommand("UpdateDecisionTable", PubsConn);
                testCMD.CommandType = CommandType.StoredProcedure;
                PubsConn.Open();
                testCMD.Parameters.Add(new SqlParameter("@identifier", identifier));
                testCMD.Parameters.Add(new SqlParameter("@lastprice", lastprice));
                testCMD.Parameters.Add(new SqlParameter("@qty", qty));
                testCMD.Parameters.Add(new SqlParameter("@indicator", indicator));
                int reader = testCMD.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public void fillBuyIndicator(string identifier, decimal lastprice, long qty, string indicator)
        {
            try
            {
                //BuySell bs = new BuySell();
                SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");

                SqlCommand testCMD = new SqlCommand("fillBuyIndicator", PubsConn);
                testCMD.CommandType = CommandType.StoredProcedure;
                PubsConn.Open();
                testCMD.Parameters.Add(new SqlParameter("@identifier", identifier));
                testCMD.Parameters.Add(new SqlParameter("@value", lastprice));
                testCMD.Parameters.Add(new SqlParameter("@qty", qty));
                int reader = testCMD.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public void UpdateBuyIndicator(string identifier, decimal lastprice, long qty, string indicator)
        {
            try
            {
                //BuySell bs = new BuySell();
                SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");

                SqlCommand testCMD = new SqlCommand("UpdateBuyIndicator", PubsConn);
                testCMD.CommandType = CommandType.StoredProcedure;
                PubsConn.Open();
                testCMD.Parameters.Add(new SqlParameter("@identifier", identifier));
                testCMD.Parameters.Add(new SqlParameter("@value", lastprice));
                testCMD.Parameters.Add(new SqlParameter("@qty", qty));
                int reader = testCMD.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public void FetchBuyOrSell()
        {
            string identifier;
            string indicator;
            int qty;
            decimal lastPrice;


            try
            {
                //BuySell bs = new BuySell();
                SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");
                SqlConnection PubsConn1 = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");
                SqlCommand testCMD = new SqlCommand("ReadDecisionTableTop3", PubsConn);
                testCMD.CommandType = CommandType.StoredProcedure;
                PubsConn.Open();
                SqlDataReader reader = testCMD.ExecuteReader();

                var dataTable = new DataTable();
                dataTable.Load(reader);

                PubsConn.Close();
                if (dataTable.Rows.Count > 0)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        identifier = dataTable.Rows[i]["identifier"].ToString();
                        indicator = dataTable.Rows[i]["indicator"].ToString();
                        lastPrice = (decimal)dataTable.Rows[i]["lastprice"];
                        qty = (int)(30000 / lastPrice);
                        qty = qty - 1;
                        if (indicator.ToLower() == "buy")
                        {
                            Buy(identifier, qty, lastPrice, "097471383", "Windows8");
                        }
                        if (indicator.ToLower() == "sell")
                        {
                            Sell(identifier, qty, lastPrice, "097471383", "Windows8");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("No rows found.");
                }
                reader.Close();
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public void Buy(string stock, long qty, decimal lastPrice, string userName, string password)
        {

            try
            {
                Contract contract = GetOrderContract_mine(stock);
                Order order = GetOrder_mine(qty);
                orderManager.PlaceOrder(contract, order);
                if (orderId != 0)
                    orderId = 0;
                this.Visible = false;
                UpdateDecisionTable(stock, lastPrice, 1, "Buy");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {

            }
        }

        public void BuyThruManualClick(string stock, long qty, decimal lastPrice, string userName, string password)
        {

            try
            {
                Contract contract = GetOrderContract_mine(stock);
                Order order = GetOrder_mine(qty);
                orderManager.PlaceOrder(contract, order);
                if (orderId != 0)
                    orderId = 0;
                //this.Visible = false;
                fillBuyIndicator(stock, lastPrice, qty, "Buy");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {

            }
        }
        public void SellThruManualClick(string stock, long qty, decimal lastPrice, string userName, string password)
        {

            try
            {
                Contract contract = GetOrderContract_mine(stock);
                Order order = SellOrder_mine(qty);
                orderManager.PlaceOrder(contract, order);
                if (orderId != 0)
                    orderId = 0;
                //this.Visible = false;
                UpdateDecisionTable(stock, lastPrice, 1, "Sell");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {

            }
        }
        public void Sell(string stock, int qty, decimal lastPrice, string userName, string password)
        {

            {
                try
                {
                    try
                    {
                        Contract contract = GetOrderContract_mine(stock);
                        Order order = GetOrder_mine(qty);
                        orderManager.PlaceOrder(contract, order);
                        if (orderId != 0)
                            orderId = 0;
                        this.Visible = false;
                        UpdateDecisionTable(stock, lastPrice, 1, "Sell");

                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                    }
                    finally
                    {

                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
                finally
                {

                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int qty=0;
            decimal price = 0;
            var button = (DataGridView)sender;
            if (e.RowIndex > -1)
            {
                string name = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells["identifier"].Value);
                if (dataGridView1.Rows[e.RowIndex].Cells["price"].Value.ToString() != string.Empty)
                {
                     price = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["price"].Value);
                }
               
                if (dataGridView1.Rows[e.RowIndex].Cells["qty"].Value.ToString() != string.Empty)
                {
                     qty = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["qty"].Value);
                }
                DataGridViewButtonCell b = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex] as DataGridViewButtonCell;
                if (b != null)
                {
                    if (b.Value.ToString() == "Buy")
                    {

                         qty = (int)(10000 / price);
                        // qty = 1;// qty - 1;
                        BuyThruManualClick(name, qty, price, "097471383", "Windows8");

                    }
                    if (b.Value.ToString() == "Sell" && qty > 0)
                    {

                         //qty = (int)(10000 / price);
                        // qty = 1;// qty - 1;
                        SellThruManualClick(name, qty, price, "097471383", "Windows8");

                    }
                }
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {

        }

        private void conditionsTab_Selected(object sender, TabControlEventArgs e)
        {

            //timerfetch.Interval = new TimeSpan(0, 0, 10);
            //timerfetch.Tick += (o, u) =>
            //{
            RefreshGridView();
            //};
            //timerfetch.Start();

        }

        SqlDataReader sqlDataReader;
        public void RefreshGridView()
        {
            try
            {
                //BuySell bs = new BuySell();
                SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");
                SqlCommand testCMD = new SqlCommand("QuerytoGetPrices", PubsConn);
                testCMD.CommandType = CommandType.StoredProcedure;
                PubsConn.Open();
               
                sqlDataReader = testCMD.ExecuteReader();
                if (sqlDataReader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Load(sqlDataReader);

                    dataGridView1.DataSource = dt;
                }

            }
            catch (Exception ex)
            {

                //throw ex;
            }

        }

        SqlDataReader sqlDataReaderbuysell;
        public void RefreshGridViewBuySell()
        {
            try
            {
                //BuySell bs = new BuySell();
                SqlConnection PubsConn = new SqlConnection("Data Source=DESKTOP-LQ3F5LT\\SQLEXPRESS;integrated Security=sspi;initial catalog=test;");
                SqlCommand testCMD = new SqlCommand("QuerytoGetBoughtStocks", PubsConn);
                testCMD.CommandType = CommandType.StoredProcedure;
                PubsConn.Open();

                sqlDataReaderbuysell = testCMD.ExecuteReader();
                if (sqlDataReaderbuysell.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Load(sqlDataReaderbuysell);

                    dataGridView2.DataSource = dt;
                }

            }
            catch (Exception ex)
            {

                 //throw ex;
            }

        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            foreach (DataGridViewRow Myrow in dataGridView1.Rows)
            {            //Here 2 cell is target value and 1 cell is Volume
                if (Myrow.Cells["profitPercentage"].Value != null && Myrow.Cells["profitPercentage"].Value.ToString() != String.Empty)
                {
                    if (Convert.ToInt32(Myrow.Cells["profitPercentage"].Value) < -0.2)// Or your condition 
                    {
                        Myrow.DefaultCellStyle.BackColor = Color.Red;
                    }
                    else
                    {
                        Myrow.DefaultCellStyle.BackColor = Color.Green;
                    }
                }
            }
        }

        private void dataGridView2_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //foreach (DataGridViewRow Myrow in dataGridView1.Rows)
            //{            //Here 2 cell is target value and 1 cell is Volume
            //    if (Myrow.Cells["profitPercentage"].Value != null && Myrow.Cells["profitPercentage"].Value.ToString() != String.Empty)
            //    {
            //        if (Convert.ToInt32(Myrow.Cells["profitPercentage"].Value) < -0.2)// Or your condition 
            //        {
            //            Myrow.DefaultCellStyle.BackColor = Color.Red;
            //        }
            //        else
            //        {
            //            Myrow.DefaultCellStyle.BackColor = Color.Green;
            //        }
            //    }
            //}
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //var button = (DataGridView)sender;
            //if (e.RowIndex > -1)
            //{
            //    string name = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells["identifier"].Value);
            //    decimal price = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["price"].Value);
            //    DataGridViewButtonCell b = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex] as DataGridViewButtonCell;
            //    if (b.Value.ToString() == "Buy")
            //    {

            //        int qty = (int)(10000 / price);
            //        qty = 1;// qty - 1;
            //        BuyThruManualClick(name, qty, price, "097471383", "Windows8");

            //    }
            //    if (b.Value.ToString() == "Sell")
            //    {

            //        int qty = (int)(10000 / price);
            //        qty = 1;// qty - 1;
            //        SellThruManualClick(name, qty, price, "097471383", "Windows8");

            //    }
            //}
        }
    }
}
